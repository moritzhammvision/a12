package com.mgmtp.a12.template.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
class ProjectTemplateServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(ProjectTemplateServerApplication.class, args);
    }
}