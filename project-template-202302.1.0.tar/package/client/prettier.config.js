module.exports = {
    tabWidth: 4,
    trailingComma: "none",
    arrowParens: "avoid",
    endOfLine: "auto",
    printWidth: 120
};
