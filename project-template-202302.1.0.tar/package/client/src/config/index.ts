export const isProduction = process.env.NODE_ENV === "production";
export * from "./logging";
export * from "./locales";
