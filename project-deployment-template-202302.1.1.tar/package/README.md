# Full stack project deployment template

__NOTE: Some instruction steps here are only applicable for project at mgm. If you are from a partner company, please use this README as a reference and process with the configuration at your organization.__

This repo is currently created for the purpose of providing a standard way for the customer project to deploy the A12 based application to the cluster.

## How to use

__Before start using this project, you should remove the internal folder if you clone directly from Bitbucket since it is only there for A12 internal usage. Then these files `.npmignore` and `package.json` at root level shall be also removed.__

You should replace the value `your-project-name` with your actual project name. After that, pushing this repo to your git repository and refer it in `full-stack-project-template` Jenkins pipelines (please follow the README in that repository) in order to set up Jenkins job for your application deployment.

__IMPORTANT:__
- Have a look at the TODO remarks in this template and adapt them accordingly to your project configuration.
- Never put raw secrets value in your repository! Raw secret in this repository is only for demonstration purpose. One of the recommendation way of securing your credentials is at [geta12.com](https://docs.geta12.com/docs/#product:build_and_deployment,artifact:a12-stack,content:asciidoc,scene:Helm_A12_Stack,anchor:encryption_decryption).
- Credentials in `src/environments/int/secrets.yaml` must be entered on your own (and encrypted) before deployment to any public environments. Please follow the security specification in your project.
- Keycloak realm file `src/environments/int/TestRealm.json` should be used only for testing and never on production.

----

# A12 Build and Deployment Pipelines

(This is one part of a complete pipeline template. For more information, please have a look also at [A12 Jenkins Build Pipelines](https://bitbucket.mgm-tp.com/projects/A12/repos/full-stack-project-template/browse/README.md).)

## Introduction

The A12 Build and Deployment Pipelines are a collection of pre-made Jenkins pipelines to help you build your application
and create deployments on the TPI dev cluster using the [Helm A12 Stack charts](https://geta12.com/docs/#product:build_and_deployment,artifact:a12-stack,content:asciidoc,scene:Helm_A12_Stack).

In this deployment template project, we provide the `Jenkinsfile` located at root folder for deployment an A12-based application following the umbrella approach. It means that all components included in the main chart in this repository will be deployed/updated at once when there is any changes in manifest files detected by Helm and Kubernetes.

## Setup Deployment job

### Setup Credentials in Jenkins

For the pipelines to work you will need the following credentials:

* a KubeConfig to access the cluster of your CI user
* the ID of your project on Rancher
* a CI user capable of accessing Artifactory
* (if you use `helm secret` plugin) a GnuPG key for decrypting secrets

KubeConfig of CI user should be added to your builder machine when the project is created and requested. Please contact TPI for more information about KubeConfig of CI user.

The ID of your project is constructed from its namespace and name. Go to your project in Rancher, click on the menu for
your project and select _View YAML_. You can find the namespace and name of your project in the `metadata` section of
the project specification. For example if your project's namespace is _a-b-cdef_ and your project's name is _g-hijkl_,
then the `PROJECT_ID` is `a-b-cdef:g-hijkl`.

You can create a new GnuPG key or upload an existing one. The key is needed to decrypt secrets placed in the _deployment
repo_. Please contact TPI to upload the GPG key permanently to your builder.

### Adapt Pipelines

You have to adapt the items in the `Jenkinsfile` marked with a _TODO_ comment. These items include information specific to
your build and deployment environment, for example the references to your KubeConfig, project ID, CI user and
GnuPG key.

Most of the information for the deployments is taken from value files located in your _deployment repo_. This repo needs
to be referenced from your pipelines in the _application repo_. You also have to specify the paths to the value files
in the repository.

### Create job in Jenkins

After adapting the Jenkinsfile matching with the configuration and need from your project, you can follow the step-by-step tutorial below to set up the deployment job using provided `Jenkinsfile`. Pay attention to blue box rounded information and adjust the information to your job correctly.
The setup will support deploying to your __int__ environment by default. Wish you to deploy to another environment, please have a look at section [(Optional) Deploy to another internal environment](#optional-deploy-to-another-internal-environment).

__1. Access to your Jenkins builder__

Normally, the url should be `<your-project-name>-jenkins.pi.mgm-tp.com`. Please have a look at your project configuration on Wiki or ask TPI for the link to the Jenkins instance.

__2. Creating new Jenkins job__

- Click on New Item

![1_new-item](./resources/images/1_new-item.png)
- Enter the item name and choose Multibranch Pipeline as the type of item

![2_new-item-config-1](./resources/images/2_new-item-config-1.png)
- Then you will see the configuration screen of the job. Below are the recommendation for a job configuration. You can freely adjust the configuration as you need. Please be aware that the link to Jenkinsfile, project repository and credentials have to be configured accordingly to your project configuration.

![3_new-item-config](./resources/images/3_new-item-config-2.png)

![3_new-item-config](./resources/images/4_new-item-config-3.png)

![5_new-item-config-4](./resources/images/5_new-item-config-4.png)
- Clicking on Save button when you are satisfied with your configuration. Jenkins will do the scanning from your repository and one item will be created.

![6_scanning-result](./resources/images/6_scanning-result.png)
- You can click on Status to see the current status of your Jenkins job. By default, there should be a branch call `main` existing in the job. You can trigger the first build within the main branch and start building your first environment.

![7_job-status](./resources/images/7_job-status.png)
- If your project is set up using [Full Stack Project Template](https://bitbucket.mgm-tp.com/projects/A12/repos/full-stack-project-template/browse), the build from `main` branch there will trigger a deployment to _int_ environment using the deployment script from `main` branch here automatically.

### (Optional) Deploy to another internal environment

For the purpose of deploying to another internal environment, we will demonstrate how to add another deployment to QA environment.

- Creating a new folder in `src/environments` called `qa`
- Copy and adapting the values of `secrets.yaml` and `values.yaml` fitting to your new environment.

![8_new-qa-env-1](./resources/images/8_new-qa-env-1.png)
- Adjusting the Jenkinsfile to add __QA__ environment to the selection.

![9_new-qa-env-2](./resources/images/9_new-qa-env-2.png)
- When you have your code in the main branch, you will be able to see another option for environment choices, call _qa_. Choosing that to deploy the application to _qa_ environment.

----

# Create user in test realm in Keycloak

__IMPORTANT: This tutorial is created only for the testing Realm providing within this repository. Never use it on PRODUCTION!__

After having your Keycloak deployed, you can follow the step-by-step below to create your first user in Keycloak so that you can use it in your application.

- Login to Keycloak Admin console. The URL depends on how your configure in your application. Normally it is `keycloak.<your-project-name>-int.<your-domain>`
- Login with your Keycloak admin credential (this credential has to be added in `/src/environment/secrets.yaml` and should be encrypted)
- After that, choose the correct Realm with name A12Realm, click on **Users** and then **Create user**. You will see a screen like below. Enter your username and other information if necessary and then click on **Create**.

![10_create-keycloak-user-1](./resources/images/10_create-keycloak-user-1.png)
- After that, you will need to create credential for your user so that it could log in to the application. Click on that **Credentials**, then **Set password**

![10_create-keycloak-user-2](./resources/images/10_create-keycloak-user-2.png)
- After enter necessary information as in the picture, click on **Save*

![10_create-keycloak-user-3](./resources/images/10_create-keycloak-user-3.png)
- Last step, you need to assign role to that user. Here we demonstrate the assigning of _admin_ user. You can do similarly for _guest_ role. Clicking on **Role mapping** tab, then choose button **Assign** role; after that you should choose the needed roles for user and the click on **Assign**

![10_create-keycloak-user-4](./resources/images/10_create-keycloak-user-4.png)

You can now use the recent created user to access to client application.
